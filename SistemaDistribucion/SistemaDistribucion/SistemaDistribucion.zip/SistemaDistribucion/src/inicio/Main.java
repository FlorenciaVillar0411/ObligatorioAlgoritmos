
package inicio;

import dominio.*;
import sistemaDistribucion.*;
import tads.*;


public class Main {
   public static void main(String[] args){
       IObligatorio obli = new Sistema();
   } 
}
