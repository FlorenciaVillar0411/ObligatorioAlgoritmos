/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;

/**
 *
 * @author flore
 */
public class Stock {
    public String matriculaCamion;
    public int codigoProd;
    public int numeroCaja;
    public int cantUnidades; 

    public Stock(String matriculaCamion, int codigoProd, int numeroCaja, int cantUnidades) {
        this.matriculaCamion = matriculaCamion;
        this.codigoProd = codigoProd;
        this.numeroCaja = numeroCaja;
        this.cantUnidades = cantUnidades;
    }
    
}
