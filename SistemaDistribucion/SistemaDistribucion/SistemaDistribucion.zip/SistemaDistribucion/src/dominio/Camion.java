
package dominio;


public class Camion {
    public String matricula;
    public int toneladasMaxSoportadas;

    public Camion(String matricula, int toneladasMaxSoportadas) {
        this.matricula = matricula;
        this.toneladasMaxSoportadas = toneladasMaxSoportadas;
    }
    
}
