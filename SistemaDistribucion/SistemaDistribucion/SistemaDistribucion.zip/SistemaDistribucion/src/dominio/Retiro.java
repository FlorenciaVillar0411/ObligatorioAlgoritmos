/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;

/**
 *
 * @author flore
 */
public class Retiro {
    public int matriculaCam;
    public int rutCliente;
    public int codProducto;
    public int cant;

    public Retiro(int matriculaCam, int rutCliente, int codProducto, int cant) {
        this.matriculaCam = matriculaCam;
        this.rutCliente = rutCliente;
        this.codProducto = codProducto;
        this.cant = cant;
    }
}
