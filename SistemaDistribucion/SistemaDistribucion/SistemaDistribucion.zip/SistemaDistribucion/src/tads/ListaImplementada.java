
package tads;



public class ListaImplementada<T> implements Lista<T> {

    private Nodo<T> inicio;
    private int cantidadElementos;
    

    @Override
    public void agregarAlPrincipio(T dato) {
        this.inicio = new Nodo<>(dato, inicio);
        this.cantidadElementos++;
    }

    //Pre !esVacia()
    @Override
    public T elminarPrincipio() {
        T dato = this.inicio.getDato();
        this.inicio = this.inicio.getSig();
        this.cantidadElementos--;
        return dato;
    }

    @Override
    public void agregarAlFinal(T dato) {
        if (esVacia()) {
            agregarAlPrincipio(dato);
        } else {
            //No es vacía --> inicio != null
            Nodo<T> nuevo = new Nodo<>(dato);
            Nodo<T> fin = this.inicio;
            while (fin.getSig() != null) {
                fin = fin.getSig();
            }
            fin.setSig(nuevo);
            fin = nuevo;
            this.cantidadElementos++;
        }
    }

    @Override
    public boolean esVacia() {
        return this.inicio == null;
    }

    @Override
    public int largo() {
        return cantidadElementos;
    }

    @Override
    public void vaciar() {
        this.inicio = null;
    }

    @Override
    public void mostrar() {
        System.out.println("");
        //mostrarIterativo();
        mostrarRecursivo(inicio);
    }

    private void mostrarIterativo() {
        Nodo<T> aux = this.inicio;
        while (aux != null) {
            System.out.print(aux.getDato() + " ");
            aux = aux.getSig();
        }
    }

    private void mostrarRecursivo(Nodo<T> nodo) {
        if (nodo != null) {
            System.out.print(nodo.getDato() + " ");
            mostrarRecursivo(nodo.getSig());
        }
    }

    @Override
    public T obtener(T dato) {
        Nodo<T> aux = this.inicio;
        while (aux != null) {
            if (aux.getDato().equals(dato)) {
                return aux.getDato();
            }
            aux = aux.getSig();
        }
        return null;
    }

    @Override
    public boolean existe(T dato) {
        return obtener(dato) != null;
    }

    @Override
    public boolean existe(String rut) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void eliminar(T dato) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void eliminar(String rut) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void eliminar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void agregarAlFinal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean existe(int nroCaja) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void obtenerFinal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mostrarPorProducto(int codProd) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}


